/**
 * Type énuméré décrivant la nature du terrain d'une case.
 */

public enum NatureTerrain {
    EAU,
    FORET,
    ROCHE,
    TERRAIN_LIBRE,
    HABITAT
}
