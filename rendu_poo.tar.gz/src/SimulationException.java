/**
 * Exception levée lors d'une erreur de simulation.
 */

public class SimulationException extends Exception {
    public SimulationException(String msg) {
        super(msg);
    }
}
